﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AviationSoftware aviationSoftware = new AviationSoftware();
            Cockpit control = new Cockpit();

            control.EngineCommand = new StartEnginesCommand(aviationSoftware);
            control.AutopilotCommand = new ToggleAutopilotCommand(aviationSoftware);
            control.LandingGearCommand = new ToggleLandingGearCommand(aviationSoftware);    

            AirControllerSingleton atc = AirControllerSingleton.Instance();
            atc.ContactAirController("Requesting altitude change clearance.");

            Console.ReadLine();

        }
    }
}
