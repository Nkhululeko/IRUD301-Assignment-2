﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    //This acts as a receiver
    public class AviationSoftware
    {
        private bool engineStarted;
        private bool toggleAutopilot;
        private bool toggleLandingGear;

        public AviationSoftware() 
        {
            this.engineStarted = false;
            this.toggleAutopilot = false;
            this.toggleLandingGear = false;
        }

        public void StartEngines()
        {
            engineStarted = true;
            if (engineStarted)
            {
                Console.WriteLine("Engine STARTED");
            }
            else
            {
                Console.WriteLine("Engine STOPPED.");
            }
        }
        public void ToggleAutopilot()
        {
            toggleAutopilot = true;

            if (toggleAutopilot)
            {
                Console.WriteLine("Autopilot is on.");
            }
            else
            {
                Console.WriteLine("Autopilot is off");
            }
        }
        public void ToggleLandingGear()
        {
            toggleLandingGear = true;

            if (toggleLandingGear)
            {
                Console.WriteLine("Landing gear is on.");
            }
            else
            {
                Console.WriteLine("Landing gear is off.");
            }
        }
    }
}
