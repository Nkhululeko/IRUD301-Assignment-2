﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AviationSoftware aviationSoftware = new AviationSoftware();

            ICommand startEngine = new StartEnginesCommand(aviationSoftware);
            ICommand toggleAutopilot = new ToggleAutopilotCommand(aviationSoftware);
            ICommand toggleLandingGear = new ToggleLandingGearCommand(aviationSoftware);

            Cockpit control = new Cockpit();

            control.setCommand(startEngine);
            control.executeCommand();
            control.undoCommand();

            control.setCommand(toggleAutopilot);
            control.executeCommand();
            control.undoCommand();

            control.setCommand(toggleLandingGear);
            control.executeCommand();
            control.undoCommand();

            AirControllerSingleton atc = AirControllerSingleton.Instance();
            atc.ContactAirController("Requesting altitude change clearance.");

            RadioAltimeter altimeter = new RadioAltimeter();

            AlarmObserver alarmObserver = new AlarmObserver(altimeter);
            AutopilotObserver autopilotObserver = new AutopilotObserver(altimeter);
            EngineObserver engineObserver = new EngineObserver(altimeter);
            

            // Simulating altitude changes
            for (int i = 0; i < 5; i++)
            {
                altimeter.setAltitude();
                Console.WriteLine();
                Console.WriteLine($"Current Altitude: {altimeter.getAltitude()} feet");
                System.Threading.Thread.Sleep(1000); // Simulate time passing
            }

            Console.ReadLine();
        }
    }
}
