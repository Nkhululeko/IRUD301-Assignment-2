﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    sealed class AirControllerSingleton
    {
        private static AirControllerSingleton instance;
        private static readonly object Locked = new object();
        private AirControllerSingleton() { }

        public static AirControllerSingleton Instance()
        {
            lock (Locked)
            {
                if (instance == null)
                {
                    instance = new AirControllerSingleton();
                }
                return instance;
            }
        }
        public void ContactAirController(string communication)
        {
            Console.WriteLine("Contacting Air Controller: " + communication);
        }
    }
}
