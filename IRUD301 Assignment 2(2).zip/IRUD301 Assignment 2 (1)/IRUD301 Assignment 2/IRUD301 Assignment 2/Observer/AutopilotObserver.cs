﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    class AutopilotObserver: IObserver
    {
        SubjectBase subject;
        
        public AutopilotObserver(SubjectBase subject)
        {
            this.subject = subject;
            this.subject.Attach(this);
        }
        public void Update(int Altitude)
        {
            bool Autopilot = false;
            bool Descend = false;

            if (Altitude > 42000 && Autopilot == false)
            {
                Console.WriteLine("Autopilot Activated");
            }
            
            else if (Altitude < 31000  && Autopilot == false && Descend == false)
            {
                Console.WriteLine("Autopilot Activated");
            }
        }
    }
}
