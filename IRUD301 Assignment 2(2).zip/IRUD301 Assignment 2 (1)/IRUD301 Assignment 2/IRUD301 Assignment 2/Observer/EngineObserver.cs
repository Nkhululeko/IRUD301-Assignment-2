﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    class EngineObserver: IObserver
    {
        SubjectBase subject;
        public EngineObserver(SubjectBase subject)
        {
            this.subject = subject;
            this.subject.Attach(this);
        }
        public void Update(int Altitude)
        {

            if (Altitude > 42000)
            {
                Console.WriteLine("Decrease engines power");
            }

            else if (Altitude < 31000)
            {
                Console.WriteLine("Increase engines power");
            }
        }
    }
}

