﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    public class ToggleLandingGearCommand : ICommand
    {
        private AviationSoftware aviationSoftware;

        public ToggleLandingGearCommand(AviationSoftware aviationSoftware)
        {
            this.aviationSoftware = aviationSoftware;
        }
        public void Execute()
        {
            aviationSoftware.ToggleLandingGear();
        }
        public void Undo()
        {
            aviationSoftware.ToggleLandingGear();
        }
    }
}
