﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AviationSoftware aviationSoftware = new AviationSoftware();

            ICommand startEngine = new StartEnginesCommand(aviationSoftware);
            ICommand toggleAutopilot = new ToggleAutopilotCommand(aviationSoftware);
            ICommand toggleLandingGear = new ToggleLandingGearCommand(aviationSoftware);

            Cockpit control = new Cockpit();

            control.setCommand(startEngine);
            control.executeCommand();

            control.setCommand(toggleAutopilot);
            control.executeCommand();

            control.setCommand(toggleLandingGear);
            control.executeCommand();

            AirControllerSingleton atc = AirControllerSingleton.Instance();
            atc.ContactAirController("Requesting altitude change clearance.");

            Console.ReadLine();

        }
    }
}
