﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    public class Cockpit
    {
        public ICommand EngineCommand {  get; set; }
        public ICommand AutopilotCommand { get; set; }
        public ICommand LandingGearCommand { get; set; }

        bool EngineOn = false;
        bool AutopilotOn = false;
        bool LandingGearOn = false;

        public void Engine()
        {
            if (EngineOn)
            {
                EngineCommand.Execute();
            }
            else
            {
                EngineCommand.Undo();
            }
        }
        public void Autopilot()
        {
            if (AutopilotOn)
            {
                AutopilotCommand.Execute();
            }
            else
            {
                AutopilotCommand.Undo();
            }
        }
        public void LendingGear()
        {
            if (LandingGearOn)
            {
                LandingGearCommand.Execute();
            }
            else
            {
                LandingGearCommand.Undo();
            }
        }
    }
}
