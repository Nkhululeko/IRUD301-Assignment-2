﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    public class Cockpit
    {
        private ICommand command;

        public void setCommand(ICommand command)
        {
            this.command = command;
        }

        public void executeCommand()
        {
            command.Execute();
        }
        
        public void undoCommand()
        {
            command.Undo();
        }
    }
}
