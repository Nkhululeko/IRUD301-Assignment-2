﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    //This acts as a receiver
    public class AviationSoftware
    {
        private bool engineStarted;
        private bool toggleAutopilot;
        private bool toggleLandingGear;

        public AviationSoftware() 
        {
            this.engineStarted = false;
            this.toggleAutopilot = false;
            this.toggleLandingGear = false;
        }

        public void StartEngines()
        {
            engineStarted = true;
            Console.WriteLine("Engine STARTED");
        }
        public void StopEngines() 
        {
            engineStarted = false;
            Console.WriteLine("Engine STOPPED.");
        }
        public void ToggleAutopilot(bool toggle)
        {
            toggleAutopilot = toggle;

            if (toggleAutopilot)
            {
                Console.WriteLine("Autopilot is on.");
            }
            else
            {
                Console.WriteLine("Autopilot is off");
            }
        }
        public void ToggleLandingGear(bool deploy)
        {
            toggleLandingGear = deploy;

            if (toggleLandingGear)
            {
                Console.WriteLine("Landing gear is on.");
            }
            else
            {
                Console.WriteLine("Landing gear is off.");
            }
        }
    }
}
