﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRUD301_Assignment_2
{
    public class AirControllerSingleton
    {
        private static AirControllerSingleton instance;
        private AirControllerSingleton() { }

        public static AirControllerSingleton Instance()
        {
                if(instance == null)
                {
                    instance = new AirControllerSingleton();
                }
                return instance;
        }
        public void ContactAirController(string communication)
        {
            Console.WriteLine("Contacting Air Controller: " + communication);
        }
    }
}
